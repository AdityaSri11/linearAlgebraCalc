def matrixEquations(a,b):
    return 1